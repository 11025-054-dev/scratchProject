import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Zen_Maru_Gothic } from 'next/font/google'
import './globals.css'

const zen = Zen_Maru_Gothic({
  weight: ['500', '700'],
  subsets: ['latin'],
  variable: '--font-zen',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'ブロックゲームラボ | ブロックをつなげてゲームを作ろう',
  description:
    'Scratchのようにブロックをつなぎ合わせて、ブラウザだけでゲームを作れるビジュアルプログラミングサイト。',
  generator: 'v0.app',
  icons: {
    icon: [
      { url: '/icon-light-32x32.png', media: '(prefers-color-scheme: light)' },
      { url: '/icon-dark-32x32.png', media: '(prefers-color-scheme: dark)' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'light',
  themeColor: '#f5f6fb',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ja" className={`light ${zen.variable}`}>
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
