export type CostumeId = 'player' | 'ball' | 'star' | 'ghost' | 'apple' | 'block'

export const COSTUMES: { id: CostumeId; name: string; rotates: boolean }[] = [
  { id: 'player', name: 'プレイヤー', rotates: false },
  { id: 'ball', name: 'ボール', rotates: true },
  { id: 'star', name: 'スター', rotates: true },
  { id: 'ghost', name: 'おばけ', rotates: false },
  { id: 'apple', name: 'リンゴ', rotates: false },
  { id: 'block', name: 'ブロック', rotates: true },
]

export const COLORS: { value: string; label: string; hex: string }[] = [
  { value: 'red', label: '赤', hex: '#ef4444' },
  { value: 'orange', label: 'オレンジ', hex: '#f97316' },
  { value: 'yellow', label: '黄', hex: '#facc15' },
  { value: 'green', label: '緑', hex: '#22c55e' },
  { value: 'blue', label: '青', hex: '#3b82f6' },
  { value: 'purple', label: '紫', hex: '#a855f7' },
  { value: 'pink', label: 'ピンク', hex: '#ec4899' },
  { value: 'black', label: '黒', hex: '#334155' },
]

export function colorHex(value: string) {
  return COLORS.find((c) => c.value === value)?.hex ?? '#3b82f6'
}

export function costumeRotates(id: string) {
  return COSTUMES.find((c) => c.id === id)?.rotates ?? true
}

function eyes(ctx: CanvasRenderingContext2D, r: number, y: number) {
  for (const side of [-1, 1]) {
    ctx.fillStyle = '#ffffff'
    ctx.beginPath()
    ctx.ellipse(side * r * 0.36, y, r * 0.24, r * 0.28, 0, 0, Math.PI * 2)
    ctx.fill()
    ctx.fillStyle = '#1e293b'
    ctx.beginPath()
    ctx.arc(side * r * 0.36 + r * 0.06, y + r * 0.04, r * 0.12, 0, Math.PI * 2)
    ctx.fill()
  }
}

export function drawCostume(
  ctx: CanvasRenderingContext2D,
  costume: string,
  hex: string,
  r: number,
) {
  ctx.lineWidth = Math.max(1.5, r * 0.08)
  ctx.strokeStyle = 'rgba(15, 23, 42, 0.35)'
  ctx.fillStyle = hex

  switch (costume) {
    case 'player': {
      ctx.beginPath()
      ctx.roundRect(-r, -r, r * 2, r * 2, r * 0.45)
      ctx.fill()
      ctx.stroke()
      eyes(ctx, r, -r * 0.15)
      ctx.strokeStyle = '#1e293b'
      ctx.lineWidth = Math.max(1.5, r * 0.08)
      ctx.beginPath()
      ctx.arc(0, r * 0.3, r * 0.28, 0.15 * Math.PI, 0.85 * Math.PI)
      ctx.stroke()
      break
    }
    case 'ball': {
      ctx.beginPath()
      ctx.arc(0, 0, r, 0, Math.PI * 2)
      ctx.fill()
      ctx.stroke()
      ctx.fillStyle = 'rgba(255,255,255,0.55)'
      ctx.beginPath()
      ctx.arc(-r * 0.35, -r * 0.35, r * 0.25, 0, Math.PI * 2)
      ctx.fill()
      break
    }
    case 'star': {
      ctx.beginPath()
      for (let i = 0; i < 10; i++) {
        const rad = i % 2 === 0 ? r : r * 0.45
        const a = -Math.PI / 2 + (i * Math.PI) / 5
        const px = Math.cos(a) * rad
        const py = Math.sin(a) * rad
        if (i === 0) ctx.moveTo(px, py)
        else ctx.lineTo(px, py)
      }
      ctx.closePath()
      ctx.fill()
      ctx.stroke()
      break
    }
    case 'ghost': {
      ctx.beginPath()
      ctx.arc(0, -r * 0.1, r * 0.9, Math.PI, 0)
      ctx.lineTo(r * 0.9, r * 0.9)
      const bumps = 3
      const w = (r * 1.8) / bumps
      for (let i = 0; i < bumps; i++) {
        const x0 = r * 0.9 - i * w
        ctx.quadraticCurveTo(x0 - w / 2, r * 0.55, x0 - w, r * 0.9)
      }
      ctx.closePath()
      ctx.fill()
      ctx.stroke()
      eyes(ctx, r * 0.9, -r * 0.15)
      break
    }
    case 'apple': {
      ctx.fillStyle = '#7c4a1e'
      ctx.fillRect(-r * 0.06, -r * 1.0, r * 0.12, r * 0.35)
      ctx.fillStyle = '#16a34a'
      ctx.beginPath()
      ctx.ellipse(r * 0.25, -r * 0.85, r * 0.25, r * 0.12, -0.5, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = hex
      ctx.beginPath()
      ctx.arc(-r * 0.35, r * 0.1, r * 0.6, 0, Math.PI * 2)
      ctx.arc(r * 0.35, r * 0.1, r * 0.6, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = 'rgba(255,255,255,0.45)'
      ctx.beginPath()
      ctx.arc(-r * 0.45, -r * 0.1, r * 0.16, 0, Math.PI * 2)
      ctx.fill()
      break
    }
    default: {
      ctx.beginPath()
      ctx.roundRect(-r, -r, r * 2, r * 2, r * 0.15)
      ctx.fill()
      ctx.stroke()
      ctx.strokeStyle = 'rgba(255,255,255,0.5)'
      ctx.beginPath()
      ctx.roundRect(-r * 0.65, -r * 0.65, r * 1.3, r * 1.3, r * 0.1)
      ctx.stroke()
    }
  }
}
