import { COLORS, COSTUMES } from './costumes'
import { SOUNDS } from './sound'

export type CategoryId = 'events' | 'motion' | 'looks' | 'sound' | 'control' | 'variables'

export const CATEGORIES: { id: CategoryId; name: string; color: string; dark: string }[] = [
  { id: 'events', name: 'イベント', color: '#d49a00', dark: '#a87800' },
  { id: 'motion', name: '動き', color: '#3d7beb', dark: '#2a5fc4' },
  { id: 'looks', name: '見た目', color: '#8a5cf6', dark: '#6b3fd6' },
  { id: 'sound', name: '音', color: '#c04fbf', dark: '#983a97' },
  { id: 'control', name: '制御', color: '#e08600', dark: '#b06900' },
  { id: 'variables', name: '変数', color: '#e5640a', dark: '#b84d05' },
]

export const CATEGORY_MAP = Object.fromEntries(CATEGORIES.map((c) => [c.id, c])) as Record<
  CategoryId,
  (typeof CATEGORIES)[number]
>

export type Option = { value: string; label: string }
export type InputSpec = {
  name: string
  kind: 'number' | 'text' | 'select'
  options?: Option[] | 'touch'
}
export type Part = string | InputSpec
export type Shape = 'hat' | 'stack' | 'c' | 'cap' | 'c-cap'
export type BlockDef = {
  category: CategoryId
  shape: Shape
  parts: Part[]
  defaults?: Record<string, string>
}

const KEY_OPTIONS: Option[] = [
  { value: 'space', label: 'スペース' },
  { value: 'up', label: '上向き矢印' },
  { value: 'down', label: '下向き矢印' },
  { value: 'left', label: '左向き矢印' },
  { value: 'right', label: '右向き矢印' },
  { value: 'a', label: 'a' },
  { value: 'd', label: 'd' },
  { value: 'w', label: 'w' },
  { value: 's', label: 's' },
  { value: 'any', label: 'どれか' },
]

const MESSAGE_OPTIONS: Option[] = [
  { value: 'start', label: 'スタート' },
  { value: 'gameover', label: 'ゲームオーバー' },
  { value: 'clear', label: 'クリア' },
  { value: 'msg1', label: 'メッセージ1' },
]

const OP_OPTIONS: Option[] = [
  { value: '>', label: '>' },
  { value: '<', label: '<' },
  { value: '=', label: '=' },
]

const n = (name: string): InputSpec => ({ name, kind: 'number' })
const t = (name: string): InputSpec => ({ name, kind: 'text' })
const sel = (name: string, options: Option[] | 'touch'): InputSpec => ({
  name,
  kind: 'select',
  options,
})

export const DEFS: Record<string, BlockDef> = {
  whenFlag: { category: 'events', shape: 'hat', parts: ['緑の旗が押されたとき'] },
  whenKey: {
    category: 'events',
    shape: 'hat',
    parts: [sel('key', KEY_OPTIONS), 'キーが押されたとき'],
    defaults: { key: 'space' },
  },
  whenClicked: { category: 'events', shape: 'hat', parts: ['このスプライトが押されたとき'] },
  whenReceive: {
    category: 'events',
    shape: 'hat',
    parts: [sel('msg', MESSAGE_OPTIONS), 'を受け取ったとき'],
    defaults: { msg: 'start' },
  },
  broadcast: {
    category: 'events',
    shape: 'stack',
    parts: [sel('msg', MESSAGE_OPTIONS), 'を送る'],
    defaults: { msg: 'start' },
  },

  move: { category: 'motion', shape: 'stack', parts: [n('steps'), '歩動かす'], defaults: { steps: '10' } },
  turnRight: {
    category: 'motion',
    shape: 'stack',
    parts: ['右に', n('deg'), '度回す'],
    defaults: { deg: '15' },
  },
  turnLeft: {
    category: 'motion',
    shape: 'stack',
    parts: ['左に', n('deg'), '度回す'],
    defaults: { deg: '15' },
  },
  pointDir: { category: 'motion', shape: 'stack', parts: [n('dir'), '度に向ける'], defaults: { dir: '90' } },
  goto: {
    category: 'motion',
    shape: 'stack',
    parts: ['x:', n('x'), 'y:', n('y'), 'へ行く'],
    defaults: { x: '0', y: '0' },
  },
  gotoRandom: { category: 'motion', shape: 'stack', parts: ['どこかの場所へ行く'] },
  changeX: {
    category: 'motion',
    shape: 'stack',
    parts: ['x座標を', n('dx'), 'ずつ変える'],
    defaults: { dx: '10' },
  },
  setX: { category: 'motion', shape: 'stack', parts: ['x座標を', n('x'), 'にする'], defaults: { x: '0' } },
  changeY: {
    category: 'motion',
    shape: 'stack',
    parts: ['y座標を', n('dy'), 'ずつ変える'],
    defaults: { dy: '10' },
  },
  setY: { category: 'motion', shape: 'stack', parts: ['y座標を', n('y'), 'にする'], defaults: { y: '0' } },
  bounce: { category: 'motion', shape: 'stack', parts: ['もし端に着いたら、跳ね返る'] },

  say: { category: 'looks', shape: 'stack', parts: [t('text'), 'と言う'], defaults: { text: 'こんにちは!' } },
  sayFor: {
    category: 'looks',
    shape: 'stack',
    parts: [t('text'), 'と', n('secs'), '秒言う'],
    defaults: { text: 'やったね!', secs: '2' },
  },
  setCostume: {
    category: 'looks',
    shape: 'stack',
    parts: ['コスチュームを', sel('costume', COSTUMES.map((c) => ({ value: c.id, label: c.name }))), 'にする'],
    defaults: { costume: 'player' },
  },
  setColor: {
    category: 'looks',
    shape: 'stack',
    parts: ['色を', sel('color', COLORS.map((c) => ({ value: c.value, label: c.label }))), 'にする'],
    defaults: { color: 'red' },
  },
  changeSize: {
    category: 'looks',
    shape: 'stack',
    parts: ['大きさを', n('d'), 'ずつ変える'],
    defaults: { d: '10' },
  },
  setSize: { category: 'looks', shape: 'stack', parts: ['大きさを', n('s'), '%にする'], defaults: { s: '100' } },
  show: { category: 'looks', shape: 'stack', parts: ['表示する'] },
  hide: { category: 'looks', shape: 'stack', parts: ['隠す'] },

  playSound: {
    category: 'sound',
    shape: 'stack',
    parts: [sel('sound', SOUNDS), 'の音を鳴らす'],
    defaults: { sound: 'pon' },
  },

  wait: { category: 'control', shape: 'stack', parts: [n('secs'), '秒待つ'], defaults: { secs: '1' } },
  repeat: { category: 'control', shape: 'c', parts: [n('times'), '回繰り返す'], defaults: { times: '10' } },
  forever: { category: 'control', shape: 'c-cap', parts: ['ずっと'] },
  ifKey: {
    category: 'control',
    shape: 'c',
    parts: ['もし', sel('key', KEY_OPTIONS), 'キーが押されたなら'],
    defaults: { key: 'space' },
  },
  ifTouching: {
    category: 'control',
    shape: 'c',
    parts: ['もし', sel('target', 'touch'), 'に触れたなら'],
    defaults: { target: 'edge' },
  },
  ifScore: {
    category: 'control',
    shape: 'c',
    parts: ['もしスコアが', sel('op', OP_OPTIONS), n('value'), 'なら'],
    defaults: { op: '>', value: '9' },
  },
  ifRandom: {
    category: 'control',
    shape: 'c',
    parts: ['もし', n('n'), '回に1回なら'],
    defaults: { n: '3' },
  },
  stopAll: { category: 'control', shape: 'cap', parts: ['すべてを止める'] },

  setScore: {
    category: 'variables',
    shape: 'stack',
    parts: ['スコアを', n('value'), 'にする'],
    defaults: { value: '0' },
  },
  changeScore: {
    category: 'variables',
    shape: 'stack',
    parts: ['スコアを', n('value'), 'ずつ変える'],
    defaults: { value: '1' },
  },
}

export const PALETTE: Record<CategoryId, string[]> = { events: [], motion: [], looks: [], sound: [], control: [], variables: [] }
for (const [type, def] of Object.entries(DEFS)) PALETTE[def.category].push(type)

export type Block = {
  id: string
  type: string
  inputs: Record<string, string>
  next: string | null
  child: string | null
}

export type Script = { id: string; x: number; y: number }

export type Sprite = {
  id: string
  name: string
  costume: string
  color: string
  x: number
  y: number
  dir: number
  size: number
  visible: boolean
  blocks: Record<string, Block>
  scripts: Script[]
}

export type Project = { sprites: Sprite[]; selectedId: string }

export function isHat(type: string) {
  return DEFS[type]?.shape === 'hat'
}

export function isCap(type: string) {
  const shape = DEFS[type]?.shape
  return shape === 'cap' || shape === 'c-cap'
}

export function isC(type: string) {
  const shape = DEFS[type]?.shape
  return shape === 'c' || shape === 'c-cap'
}

export function randomId(prefix = 'b') {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`
}

export function createBlock(type: string, inputs: Record<string, string> = {}, id = randomId()): Block {
  return { id, type, inputs: { ...(DEFS[type]?.defaults ?? {}), ...inputs }, next: null, child: null }
}

export function lastInChain(blocks: Record<string, Block>, id: string) {
  let current = blocks[id]
  while (current?.next && blocks[current.next]) current = blocks[current.next]
  return current
}

function findParent(blocks: Record<string, Block>, id: string) {
  for (const b of Object.values(blocks)) {
    if (b.next === id) return { parent: b, kind: 'next' as const }
    if (b.child === id) return { parent: b, kind: 'child' as const }
  }
  return null
}

export function findTop(blocks: Record<string, Block>, id: string) {
  let current = id
  let parent = findParent(blocks, current)
  while (parent) {
    current = parent.parent.id
    parent = findParent(blocks, current)
  }
  return current
}

export function detach(sprite: Sprite, id: string): Sprite {
  const found = findParent(sprite.blocks, id)
  if (!found) {
    return { ...sprite, scripts: sprite.scripts.filter((s) => s.id !== id) }
  }
  const parent = { ...found.parent, [found.kind]: null }
  return { ...sprite, blocks: { ...sprite.blocks, [parent.id]: parent } }
}

export function attach(
  sprite: Sprite,
  draggedId: string,
  target: { kind: 'after' | 'mouth'; id: string },
): Sprite {
  const blocks = { ...sprite.blocks }
  const host = blocks[target.id]
  const last = lastInChain(blocks, draggedId)
  if (!host || !last) return sprite
  const displaced = target.kind === 'after' ? host.next : host.child
  if (last.id !== draggedId || displaced) blocks[last.id] = { ...last, next: displaced }
  else blocks[last.id] = { ...last, next: null }
  blocks[host.id] = target.kind === 'after' ? { ...host, next: draggedId } : { ...host, child: draggedId }
  return { ...sprite, blocks }
}

export function addScript(sprite: Sprite, id: string, x: number, y: number): Sprite {
  return { ...sprite, scripts: [...sprite.scripts.filter((s) => s.id !== id), { id, x, y }] }
}

export function deleteChain(sprite: Sprite, id: string): Sprite {
  const blocks = { ...sprite.blocks }
  const remove = (start: string | null) => {
    let current = start
    while (current && blocks[current]) {
      const b = blocks[current]
      remove(b.child)
      delete blocks[current]
      current = b.next
    }
  }
  remove(id)
  return { ...sprite, blocks, scripts: sprite.scripts.filter((s) => s.id !== id) }
}

type Spec = { type: string; inputs?: Record<string, string>; child?: Spec[] }

function buildChain(blocks: Record<string, Block>, specs: Spec[], nextId: () => string): string | null {
  let first: string | null = null
  let prev: Block | null = null
  for (const spec of specs) {
    const block = createBlock(spec.type, spec.inputs, nextId())
    if (spec.child) block.child = buildChain(blocks, spec.child, nextId)
    blocks[block.id] = block
    if (prev) prev.next = block.id
    else first = block.id
    prev = block
  }
  return first
}

function makeSprite(
  base: Omit<Sprite, 'blocks' | 'scripts'>,
  scripts: { x: number; y: number; specs: Spec[] }[],
): Sprite {
  let counter = 0
  const nextId = () => `${base.id}-${counter++}`
  const blocks: Record<string, Block> = {}
  const list: Script[] = []
  for (const script of scripts) {
    const id = buildChain(blocks, script.specs, nextId)
    if (id) list.push({ id, x: script.x, y: script.y })
  }
  return { ...base, blocks, scripts: list }
}

export function createEmptySprite(costume: string, name: string, color: string, id = randomId('sprite')): Sprite {
  return { id, name, costume, color, x: 0, y: 0, dir: 90, size: 100, visible: true, blocks: {}, scripts: [] }
}

export function createSampleProject(): Project {
  const player = makeSprite(
    { id: 'sprite-player', name: 'プレイヤー', costume: 'player', color: 'blue', x: 0, y: 0, dir: 90, size: 100, visible: true },
    [
      {
        x: 24,
        y: 56,
        specs: [
          { type: 'whenFlag' },
          { type: 'goto', inputs: { x: '0', y: '-120' } },
          { type: 'setScore', inputs: { value: '0' } },
          { type: 'sayFor', inputs: { text: '星を10こ集めよう!', secs: '1.5' } },
          {
            type: 'forever',
            child: [
              { type: 'ifKey', inputs: { key: 'right' }, child: [{ type: 'changeX', inputs: { dx: '6' } }] },
              { type: 'ifKey', inputs: { key: 'left' }, child: [{ type: 'changeX', inputs: { dx: '-6' } }] },
              { type: 'ifKey', inputs: { key: 'up' }, child: [{ type: 'changeY', inputs: { dy: '6' } }] },
              { type: 'ifKey', inputs: { key: 'down' }, child: [{ type: 'changeY', inputs: { dy: '-6' } }] },
              {
                type: 'ifScore',
                inputs: { op: '>', value: '9' },
                child: [
                  { type: 'playSound', inputs: { sound: 'jump' } },
                  { type: 'say', inputs: { text: 'クリア!' } },
                  { type: 'stopAll' },
                ],
              },
            ],
          },
        ],
      },
    ],
  )

  const star = makeSprite(
    { id: 'sprite-star', name: 'スター', costume: 'star', color: 'yellow', x: 120, y: 60, dir: 90, size: 90, visible: true },
    [
      {
        x: 24,
        y: 56,
        specs: [
          { type: 'whenFlag' },
          { type: 'gotoRandom' },
          {
            type: 'forever',
            child: [
              { type: 'turnRight', inputs: { deg: '3' } },
              {
                type: 'ifTouching',
                inputs: { target: 'sprite:sprite-player' },
                child: [
                  { type: 'playSound', inputs: { sound: 'piko' } },
                  { type: 'changeScore', inputs: { value: '1' } },
                  { type: 'gotoRandom' },
                ],
              },
            ],
          },
        ],
      },
    ],
  )

  const ghost = makeSprite(
    { id: 'sprite-ghost', name: 'おばけ', costume: 'ghost', color: 'purple', x: -150, y: 100, dir: 135, size: 100, visible: true },
    [
      {
        x: 24,
        y: 56,
        specs: [
          { type: 'whenFlag' },
          { type: 'goto', inputs: { x: '-150', y: '100' } },
          { type: 'pointDir', inputs: { dir: '135' } },
          { type: 'wait', inputs: { secs: '1.5' } },
          {
            type: 'forever',
            child: [
              { type: 'move', inputs: { steps: '3' } },
              { type: 'bounce' },
              {
                type: 'ifTouching',
                inputs: { target: 'sprite:sprite-player' },
                child: [
                  { type: 'playSound', inputs: { sound: 'boo' } },
                  { type: 'say', inputs: { text: 'ゲームオーバー!' } },
                  { type: 'stopAll' },
                ],
              },
            ],
          },
        ],
      },
    ],
  )

  return { sprites: [player, star, ghost], selectedId: player.id }
}
