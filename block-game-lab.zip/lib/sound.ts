let audio: AudioContext | null = null

export const SOUNDS = [
  { value: 'pon', label: 'ポン' },
  { value: 'piko', label: 'ピコーン' },
  { value: 'boo', label: 'ブー' },
  { value: 'jump', label: 'ジャンプ' },
]

type Note = { type: OscillatorType; from: number; to: number; at: number; dur: number }

const PRESETS: Record<string, Note[]> = {
  pon: [{ type: 'sine', from: 660, to: 440, at: 0, dur: 0.15 }],
  piko: [
    { type: 'square', from: 988, to: 988, at: 0, dur: 0.08 },
    { type: 'square', from: 1319, to: 1319, at: 0.08, dur: 0.2 },
  ],
  boo: [{ type: 'sawtooth', from: 200, to: 110, at: 0, dur: 0.45 }],
  jump: [{ type: 'sine', from: 300, to: 950, at: 0, dur: 0.22 }],
}

export function playSound(name: string) {
  if (typeof window === 'undefined') return
  audio ??= new AudioContext()
  if (audio.state === 'suspended') void audio.resume()
  const notes = PRESETS[name] ?? PRESETS.pon
  const now = audio.currentTime
  for (const note of notes) {
    const osc = audio.createOscillator()
    const gain = audio.createGain()
    osc.type = note.type
    osc.frequency.setValueAtTime(note.from, now + note.at)
    osc.frequency.exponentialRampToValueAtTime(note.to, now + note.at + note.dur)
    gain.gain.setValueAtTime(0.12, now + note.at)
    gain.gain.exponentialRampToValueAtTime(0.001, now + note.at + note.dur)
    osc.connect(gain).connect(audio.destination)
    osc.start(now + note.at)
    osc.stop(now + note.at + note.dur + 0.02)
  }
}
