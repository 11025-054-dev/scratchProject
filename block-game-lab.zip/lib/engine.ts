import { isHat, type Block, type Project, type Sprite } from './blocks'
import { playSound } from './sound'

export const STAGE_W = 480
export const STAGE_H = 360
export const BASE_RADIUS = 24

export type SpriteState = {
  id: string
  name: string
  costume: string
  color: string
  x: number
  y: number
  dir: number
  size: number
  visible: boolean
  say: string | null
}

type Signal = 'halt' | undefined
type Thread = {
  spriteId: string
  topId: string
  gen: Generator<undefined, Signal, unknown>
  done: boolean
  killed: boolean
}

const toNum = (v: string | undefined) => {
  const n = Number(v)
  return Number.isFinite(n) ? n : 0
}

const clamp = (v: number, min: number, max: number) => Math.min(max, Math.max(min, v))

function normalizeDir(d: number) {
  const r = (((d + 180) % 360) + 360) % 360 - 180
  return r === -180 ? 180 : r
}

export function normalizeKey(key: string) {
  switch (key) {
    case ' ':
      return 'space'
    case 'ArrowUp':
      return 'up'
    case 'ArrowDown':
      return 'down'
    case 'ArrowLeft':
      return 'left'
    case 'ArrowRight':
      return 'right'
    default:
      return key.length === 1 ? key.toLowerCase() : key
  }
}

export function radiusOf(s: SpriteState) {
  return (BASE_RADIUS * s.size) / 100
}

export class Engine {
  sprites = new Map<string, SpriteState>()
  order: string[] = []
  score = 0
  keys = new Set<string>()
  mouse = { x: 0, y: 0 }
  running = false
  private threads: Thread[] = []
  private listeners = new Set<() => void>()

  constructor(private getProject: () => Project) {}

  subscribe = (listener: () => void) => {
    this.listeners.add(listener)
    return () => {
      this.listeners.delete(listener)
    }
  }

  getRunning = () => this.running

  private updateRunning() {
    const running = this.threads.length > 0
    if (running !== this.running) {
      this.running = running
      for (const l of this.listeners) l()
    }
  }

  private toState(s: Sprite): SpriteState {
    return {
      id: s.id,
      name: s.name,
      costume: s.costume,
      color: s.color,
      x: s.x,
      y: s.y,
      dir: s.dir,
      size: s.size,
      visible: s.visible,
      say: null,
    }
  }

  reset(sprites: Sprite[]) {
    this.stopAll()
    this.sprites.clear()
    for (const s of sprites) this.sprites.set(s.id, this.toState(s))
    this.order = sprites.map((s) => s.id)
    this.score = 0
  }

  sync(sprites: Sprite[]) {
    const ids = new Set(sprites.map((s) => s.id))
    for (const id of [...this.sprites.keys()]) {
      if (!ids.has(id)) {
        this.sprites.delete(id)
        for (const t of this.threads) if (t.spriteId === id) t.killed = true
      }
    }
    for (const s of sprites) {
      const existing = this.sprites.get(s.id)
      if (existing) existing.name = s.name
      else this.sprites.set(s.id, this.toState(s))
    }
    this.order = sprites.map((s) => s.id)
  }

  setProps(id: string, props: Partial<SpriteState>) {
    const s = this.sprites.get(id)
    if (s) Object.assign(s, props)
  }

  private blocksOf(spriteId: string): Record<string, Block> | undefined {
    return this.getProject().sprites.find((s) => s.id === spriteId)?.blocks
  }

  private startHats(match: (block: Block) => boolean, restart: boolean) {
    for (const sprite of this.getProject().sprites) {
      for (const script of sprite.scripts) {
        const top = sprite.blocks[script.id]
        if (!top || !match(top)) continue
        const existing = this.threads.find((t) => t.topId === top.id && !t.killed && !t.done)
        if (existing) {
          if (!restart) continue
          existing.killed = true
        }
        this.spawn(sprite.id, top.id, top.next)
      }
    }
    this.threads = this.threads.filter((t) => !t.killed)
    this.updateRunning()
  }

  private spawn(spriteId: string, topId: string, startId: string | null) {
    this.threads.push({ spriteId, topId, gen: this.exec(spriteId, startId), done: false, killed: false })
  }

  greenFlag() {
    this.stopAll()
    for (const s of this.sprites.values()) s.say = null
    this.startHats((b) => b.type === 'whenFlag', true)
  }

  stopAll() {
    for (const t of this.threads) t.killed = true
    this.threads = []
    this.updateRunning()
  }

  keyDown(key: string) {
    this.keys.add(key)
    this.startHats((b) => b.type === 'whenKey' && (b.inputs.key === key || b.inputs.key === 'any'), false)
  }

  keyUp(key: string) {
    this.keys.delete(key)
  }

  clearKeys() {
    this.keys.clear()
  }

  clickSprite(id: string) {
    for (const sprite of this.getProject().sprites) {
      if (sprite.id !== id) continue
      for (const script of sprite.scripts) {
        const top = sprite.blocks[script.id]
        if (top?.type !== 'whenClicked') continue
        for (const t of this.threads) if (t.topId === top.id) t.killed = true
        this.spawn(sprite.id, top.id, top.next)
      }
    }
    this.threads = this.threads.filter((t) => !t.killed)
    this.updateRunning()
  }

  private broadcast(msg: string) {
    this.startHats((b) => b.type === 'whenReceive' && b.inputs.msg === msg, true)
  }

  toggleScript(spriteId: string, topId: string) {
    const running = this.threads.find((t) => t.topId === topId && !t.killed)
    if (running) {
      running.killed = true
    } else {
      const top = this.blocksOf(spriteId)?.[topId]
      if (top) this.spawn(spriteId, topId, isHat(top.type) ? top.next : top.id)
    }
    this.threads = this.threads.filter((t) => !t.killed)
    this.updateRunning()
  }

  isScriptRunning(topId: string) {
    return this.threads.some((t) => t.topId === topId && !t.killed)
  }

  step() {
    for (const t of [...this.threads]) {
      if (t.killed || t.done) continue
      const result = t.gen.next()
      if (result.done) t.done = true
    }
    this.threads = this.threads.filter((t) => !t.done && !t.killed)
    this.updateRunning()
  }

  private isKey(key: string) {
    return key === 'any' ? this.keys.size > 0 : this.keys.has(key)
  }

  private touching(s: SpriteState, target: string) {
    if (!s.visible) return false
    const r = radiusOf(s) * 0.85
    if (target === 'edge') return Math.abs(s.x) + r >= 240 || Math.abs(s.y) + r >= 180
    if (target === 'mouse') return Math.hypot(s.x - this.mouse.x, s.y - this.mouse.y) < r
    if (target.startsWith('sprite:')) {
      const other = this.sprites.get(target.slice(7))
      if (!other || other === s || !other.visible) return false
      return Math.hypot(s.x - other.x, s.y - other.y) < r + radiusOf(other) * 0.85
    }
    return false
  }

  private fence(s: SpriteState) {
    s.x = clamp(s.x, -240, 240)
    s.y = clamp(s.y, -180, 180)
  }

  private bounce(s: SpriteState) {
    const r = radiusOf(s)
    const rad = (s.dir * Math.PI) / 180
    let dx = Math.sin(rad)
    let dy = Math.cos(rad)
    if (s.x + r > 240) {
      s.x = 240 - r
      dx = -Math.abs(dx)
    } else if (s.x - r < -240) {
      s.x = -240 + r
      dx = Math.abs(dx)
    }
    if (s.y + r > 180) {
      s.y = 180 - r
      dy = -Math.abs(dy)
    } else if (s.y - r < -180) {
      s.y = -180 + r
      dy = Math.abs(dy)
    }
    s.dir = normalizeDir((Math.atan2(dx, dy) * 180) / Math.PI)
  }

  private *sleep(secs: number): Generator<undefined, void, unknown> {
    const end = performance.now() + Math.max(0, secs) * 1000
    do {
      yield
    } while (performance.now() < end)
  }

  private *exec(spriteId: string, startId: string | null): Generator<undefined, Signal, unknown> {
    let id = startId
    while (id) {
      const b = this.blocksOf(spriteId)?.[id]
      const s = this.sprites.get(spriteId)
      if (!b) return
      if (!s) return 'halt'
      const num = (key: string) => toNum(b.inputs[key])

      switch (b.type) {
        case 'move': {
          const rad = (s.dir * Math.PI) / 180
          s.x += num('steps') * Math.sin(rad)
          s.y += num('steps') * Math.cos(rad)
          this.fence(s)
          break
        }
        case 'turnRight':
          s.dir = normalizeDir(s.dir + num('deg'))
          break
        case 'turnLeft':
          s.dir = normalizeDir(s.dir - num('deg'))
          break
        case 'pointDir':
          s.dir = normalizeDir(num('dir'))
          break
        case 'goto':
          s.x = num('x')
          s.y = num('y')
          this.fence(s)
          break
        case 'gotoRandom':
          s.x = Math.round(Math.random() * 400 - 200)
          s.y = Math.round(Math.random() * 280 - 140)
          break
        case 'changeX':
          s.x += num('dx')
          this.fence(s)
          break
        case 'setX':
          s.x = num('x')
          this.fence(s)
          break
        case 'changeY':
          s.y += num('dy')
          this.fence(s)
          break
        case 'setY':
          s.y = num('y')
          this.fence(s)
          break
        case 'bounce':
          this.bounce(s)
          break
        case 'say':
          s.say = b.inputs.text || null
          break
        case 'sayFor': {
          const text = b.inputs.text || ''
          s.say = text
          yield* this.sleep(num('secs'))
          if (s.say === text) s.say = null
          break
        }
        case 'setCostume':
          s.costume = b.inputs.costume
          break
        case 'setColor':
          s.color = b.inputs.color
          break
        case 'changeSize':
          s.size = clamp(s.size + num('d'), 10, 400)
          break
        case 'setSize':
          s.size = clamp(num('s'), 10, 400)
          break
        case 'show':
          s.visible = true
          break
        case 'hide':
          s.visible = false
          break
        case 'playSound':
          playSound(b.inputs.sound)
          break
        case 'broadcast':
          this.broadcast(b.inputs.msg)
          break
        case 'wait':
          yield* this.sleep(num('secs'))
          break
        case 'repeat': {
          const times = Math.max(0, Math.round(num('times')))
          for (let i = 0; i < times; i++) {
            if ((yield* this.exec(spriteId, b.child)) === 'halt') return 'halt'
            yield
          }
          break
        }
        case 'forever':
          while (true) {
            if ((yield* this.exec(spriteId, b.child)) === 'halt') return 'halt'
            yield
          }
        case 'ifKey':
        case 'ifTouching':
        case 'ifScore':
        case 'ifRandom': {
          let ok = false
          if (b.type === 'ifKey') ok = this.isKey(b.inputs.key)
          else if (b.type === 'ifTouching') ok = this.touching(s, b.inputs.target)
          else if (b.type === 'ifRandom') ok = Math.random() < 1 / Math.max(1, num('n'))
          else {
            const v = num('value')
            ok = b.inputs.op === '<' ? this.score < v : b.inputs.op === '=' ? this.score === v : this.score > v
          }
          if (ok && (yield* this.exec(spriteId, b.child)) === 'halt') return 'halt'
          break
        }
        case 'stopAll':
          this.stopAll()
          return 'halt'
        case 'setScore':
          this.score = num('value')
          break
        case 'changeScore':
          this.score += num('value')
          break
      }
      id = b.next
    }
  }
}
