import { colorHex, costumeRotates, drawCostume } from './costumes'
import { radiusOf, STAGE_H, STAGE_W, type Engine } from './engine'

function wrapText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number) {
  const lines: string[] = []
  let line = ''
  for (const ch of text) {
    if (ctx.measureText(line + ch).width > maxWidth && line) {
      lines.push(line)
      line = ch
    } else {
      line += ch
    }
  }
  if (line) lines.push(line)
  return lines.slice(0, 4)
}

export function drawStage(ctx: CanvasRenderingContext2D, engine: Engine, font: string) {
  ctx.fillStyle = '#ffffff'
  ctx.fillRect(0, 0, STAGE_W, STAGE_H)
  ctx.strokeStyle = '#eef1f8'
  ctx.lineWidth = 1
  ctx.beginPath()
  for (let x = 0; x <= STAGE_W; x += 40) {
    ctx.moveTo(x + 0.5, 0)
    ctx.lineTo(x + 0.5, STAGE_H)
  }
  for (let y = 0; y <= STAGE_H; y += 40) {
    ctx.moveTo(0, y + 0.5)
    ctx.lineTo(STAGE_W, y + 0.5)
  }
  ctx.stroke()

  for (const id of engine.order) {
    const s = engine.sprites.get(id)
    if (!s?.visible) continue
    ctx.save()
    ctx.translate(STAGE_W / 2 + s.x, STAGE_H / 2 - s.y)
    if (costumeRotates(s.costume)) ctx.rotate(((s.dir - 90) * Math.PI) / 180)
    drawCostume(ctx, s.costume, colorHex(s.color), radiusOf(s))
    ctx.restore()
  }

  ctx.font = `700 14px ${font}`
  ctx.textBaseline = 'top'
  for (const id of engine.order) {
    const s = engine.sprites.get(id)
    if (!s?.visible || !s.say) continue
    const lines = wrapText(ctx, s.say, 150)
    const w = Math.max(...lines.map((l) => ctx.measureText(l).width)) + 20
    const h = lines.length * 18 + 14
    const sx = STAGE_W / 2 + s.x
    const sy = STAGE_H / 2 - s.y
    const r = radiusOf(s)
    const bx = Math.min(Math.max(sx + r * 0.4, 4), STAGE_W - w - 4)
    const by = Math.max(sy - r - h - 12, 4)
    ctx.fillStyle = '#ffffff'
    ctx.strokeStyle = '#c7cede'
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.roundRect(bx, by, w, h, 12)
    ctx.fill()
    ctx.stroke()
    ctx.fillStyle = '#1e2433'
    lines.forEach((l, i) => ctx.fillText(l, bx + 10, by + 8 + i * 18))
  }

  const label = `スコア  ${engine.score}`
  ctx.font = `700 13px ${font}`
  const lw = ctx.measureText(label).width + 20
  ctx.fillStyle = 'rgba(229, 100, 10, 0.92)'
  ctx.beginPath()
  ctx.roundRect(8, 8, lw, 26, 13)
  ctx.fill()
  ctx.fillStyle = '#ffffff'
  ctx.textBaseline = 'middle'
  ctx.fillText(label, 18, 21.5)
}
