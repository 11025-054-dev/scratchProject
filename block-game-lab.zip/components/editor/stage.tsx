'use client'

import { useEffect, useRef, useSyncExternalStore, type PointerEvent as ReactPointerEvent } from 'react'
import { Flag, Square } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { radiusOf, STAGE_H, STAGE_W, type Engine } from '@/lib/engine'
import { drawStage } from '@/lib/render'
import { cn } from '@/lib/utils'

const FRAME_MS = 1000 / 60

type StageProps = {
  engine: Engine
  onSpritePick: (id: string) => void
  onSpriteMoved: (id: string, x: number, y: number) => void
}

export function Stage({ engine, onSpritePick, onSpriteMoved }: StageProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const dragRef = useRef<{ id: string; dx: number; dy: number; moved: boolean; sx: number; sy: number } | null>(null)
  const running = useSyncExternalStore(engine.subscribe, engine.getRunning, () => false)

  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas?.getContext('2d')
    if (!canvas || !ctx) return
    const dpr = Math.min(2, window.devicePixelRatio || 1)
    canvas.width = STAGE_W * dpr
    canvas.height = STAGE_H * dpr
    const font = getComputedStyle(canvas).fontFamily || 'sans-serif'
    let raf = 0
    let last = performance.now()
    let acc = 0
    const frame = (now: number) => {
      acc += Math.min(100, now - last)
      last = now
      let steps = 0
      while (acc >= FRAME_MS && steps < 3) {
        engine.step()
        acc -= FRAME_MS
        steps++
      }
      if (steps === 3) acc = 0
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      drawStage(ctx, engine, font)
      raf = requestAnimationFrame(frame)
    }
    raf = requestAnimationFrame(frame)
    return () => cancelAnimationFrame(raf)
  }, [engine])

  const toStage = (e: ReactPointerEvent) => {
    const rect = canvasRef.current!.getBoundingClientRect()
    const sx = ((e.clientX - rect.left) / rect.width) * STAGE_W
    const sy = ((e.clientY - rect.top) / rect.height) * STAGE_H
    return { x: sx - STAGE_W / 2, y: STAGE_H / 2 - sy }
  }

  const onPointerDown = (e: ReactPointerEvent<HTMLCanvasElement>) => {
    const p = toStage(e)
    for (let i = engine.order.length - 1; i >= 0; i--) {
      const s = engine.sprites.get(engine.order[i])
      if (!s?.visible) continue
      if (Math.hypot(s.x - p.x, s.y - p.y) <= radiusOf(s)) {
        e.currentTarget.setPointerCapture(e.pointerId)
        dragRef.current = { id: s.id, dx: s.x - p.x, dy: s.y - p.y, moved: false, sx: p.x, sy: p.y }
        onSpritePick(s.id)
        return
      }
    }
  }

  const onPointerMove = (e: ReactPointerEvent<HTMLCanvasElement>) => {
    const p = toStage(e)
    engine.mouse = p
    const d = dragRef.current
    if (!d) return
    if (!d.moved && Math.hypot(p.x - d.sx, p.y - d.sy) > 3) d.moved = true
    if (d.moved) {
      engine.setProps(d.id, {
        x: Math.round(Math.max(-240, Math.min(240, p.x + d.dx))),
        y: Math.round(Math.max(-180, Math.min(180, p.y + d.dy))),
      })
    }
  }

  const onPointerUp = () => {
    const d = dragRef.current
    dragRef.current = null
    if (!d) return
    if (d.moved) {
      const s = engine.sprites.get(d.id)
      if (s) onSpriteMoved(d.id, s.x, s.y)
    } else {
      engine.clickSprite(d.id)
    }
  }

  return (
    <section aria-label="ステージ" className="flex flex-col gap-2 p-3">
      <div className="flex items-center justify-between gap-2">
        <h2 className="text-sm font-bold">ステージ</h2>
        <div className="flex items-center gap-2">
          <Button
            type="button"
            size="sm"
            onClick={() => engine.greenFlag()}
            className={cn(
              'bg-go text-go-foreground hover:bg-go/90',
              running && 'ring-2 ring-go/40 ring-offset-2 ring-offset-background',
            )}
          >
            <Flag className="size-4" aria-hidden />
            スタート
          </Button>
          <Button type="button" size="sm" variant="outline" onClick={() => engine.stopAll()}>
            <Square className="size-3.5 fill-destructive text-destructive" aria-hidden />
            ストップ
          </Button>
        </div>
      </div>
      <canvas
        ref={canvasRef}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        className="aspect-[4/3] w-full touch-none rounded-xl border bg-white shadow-sm"
        aria-label="ゲームのステージ。スプライトをドラッグして動かせます"
        role="img"
      />
    </section>
  )
}
