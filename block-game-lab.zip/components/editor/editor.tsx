'use client'

import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type PointerEvent as ReactPointerEvent,
} from 'react'
import {
  DEFS,
  addScript,
  attach,
  createBlock,
  createEmptySprite,
  createSampleProject,
  deleteChain,
  detach,
  findTop,
  isCap,
  isHat,
  lastInChain,
  randomId,
  type Option,
  type Project,
  type Sprite,
} from '@/lib/blocks'
import { COSTUMES } from '@/lib/costumes'
import { Engine, normalizeKey } from '@/lib/engine'
import { BlockStack, type BlockContext } from './block-view'
import { EditorHeader } from './editor-header'
import { Palette } from './palette'
import { SpritePanel } from './sprite-panel'
import { Stage } from './stage'
import { Workspace, type SnapTarget } from './workspace'

type DragState = {
  phase: 'pending' | 'dragging'
  source: 'palette' | 'workspace'
  blockType?: string
  blockId?: string
  startX: number
  startY: number
  offsetX: number
  offsetY: number
  x: number
  y: number
}

const SNAP_DISTANCE = 30

function isEditable(target: EventTarget | null) {
  return target instanceof HTMLElement && !!target.closest('input, select, textarea, [contenteditable="true"]')
}

export function Editor() {
  const [project, setProject] = useState<Project>(createSampleProject)
  const projectRef = useRef(project)
  const [engine] = useState(() => {
    const e = new Engine(() => projectRef.current)
    e.reset(project.sprites)
    return e
  })
  const [drag, setDrag] = useState<DragState | null>(null)
  const [snap, setSnap] = useState<SnapTarget | null>(null)
  const dragRef = useRef<DragState | null>(null)
  const snapRef = useRef<SnapTarget | null>(null)
  const paletteRef = useRef<HTMLDivElement>(null)
  const wsScrollRef = useRef<HTMLDivElement>(null)
  const wsContentRef = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    projectRef.current = project
  }, [project])

  useEffect(() => {
    engine.sync(project.sprites)
  }, [engine, project.sprites])

  const selected = project.sprites.find((s) => s.id === project.selectedId) ?? project.sprites[0]
  const selectedId = selected.id

  const updateSprite = useCallback((id: string, fn: (s: Sprite) => Sprite) => {
    setProject((p) => ({ ...p, sprites: p.sprites.map((s) => (s.id === id ? fn(s) : s)) }))
  }, [])

  const setDragState = (d: DragState | null) => {
    dragRef.current = d
    setDrag(d)
  }
  const setSnapState = (s: SnapTarget | null) => {
    snapRef.current = s
    setSnap(s)
  }

  const touchOptions = useMemo<Option[]>(
    () => [
      { value: 'edge', label: '端' },
      { value: 'mouse', label: 'マウスのポインター' },
      ...project.sprites.filter((s) => s.id !== selectedId).map((s) => ({ value: `sprite:${s.id}`, label: s.name })),
    ],
    [project.sprites, selectedId],
  )

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (isEditable(e.target) || e.metaKey || e.ctrlKey) return
      const key = normalizeKey(e.key)
      if (['space', 'up', 'down', 'left', 'right'].includes(key)) e.preventDefault()
      engine.keyDown(key)
    }
    const onKeyUp = (e: KeyboardEvent) => engine.keyUp(normalizeKey(e.key))
    const onBlur = () => engine.clearKeys()
    window.addEventListener('keydown', onKeyDown)
    window.addEventListener('keyup', onKeyUp)
    window.addEventListener('blur', onBlur)
    return () => {
      window.removeEventListener('keydown', onKeyDown)
      window.removeEventListener('keyup', onKeyUp)
      window.removeEventListener('blur', onBlur)
    }
  }, [engine])

  const findSnap = (d: DragState): SnapTarget | null => {
    const content = wsContentRef.current
    const sprite = projectRef.current.sprites.find((s) => s.id === projectRef.current.selectedId)
    if (!content || !sprite || !d.blockId) return null
    const dragged = sprite.blocks[d.blockId]
    if (!dragged || isHat(dragged.type)) return null
    const endsWithCap = isCap(lastInChain(sprite.blocks, d.blockId)?.type ?? '')
    const left = d.x - d.offsetX
    const top = d.y - d.offsetY
    const base = content.getBoundingClientRect()
    let best: SnapTarget | null = null
    let bestDist = SNAP_DISTANCE
    content.querySelectorAll<HTMLElement>('[data-snap-kind]').forEach((el) => {
      const kind = el.dataset.snapKind as 'after' | 'mouth'
      const id = el.dataset.snapId
      const host = id ? sprite.blocks[id] : undefined
      if (!id || !host) return
      const occupied = kind === 'after' ? host.next : host.child
      if (endsWithCap && occupied) return
      const r = el.getBoundingClientRect()
      const px = r.left
      const py = kind === 'after' ? r.bottom : r.top
      const dist = Math.hypot(left - px, top - py)
      if (dist < bestDist) {
        bestDist = dist
        best = { kind, id, x: px - base.left, y: py - base.top }
      }
    })
    return best
  }

  const isDragging = drag !== null

  useEffect(() => {
    if (!isDragging) return

    const onMove = (e: PointerEvent) => {
      let d = dragRef.current
      if (!d) return
      d = { ...d, x: e.clientX, y: e.clientY }
      if (d.phase === 'pending' && Math.hypot(d.x - d.startX, d.y - d.startY) > 4) {
        if (d.source === 'palette' && d.blockType) {
          const block = createBlock(d.blockType)
          updateSprite(selectedId, (s) => ({ ...s, blocks: { ...s.blocks, [block.id]: block } }))
          d = { ...d, phase: 'dragging', blockId: block.id }
        } else if (d.blockId) {
          const id = d.blockId
          updateSprite(selectedId, (s) => detach(s, id))
          d = { ...d, phase: 'dragging' }
        }
      }
      setDragState(d)
      if (d.phase === 'dragging') setSnapState(findSnap(d))
    }

    const onUp = (e: PointerEvent) => {
      const d = dragRef.current
      const target = snapRef.current
      setDragState(null)
      setSnapState(null)
      if (!d) return

      if (d.phase === 'pending') {
        if (d.source === 'workspace' && d.blockId) {
          const top = findTop(projectRef.current.sprites.find((s) => s.id === selectedId)?.blocks ?? {}, d.blockId)
          engine.toggleScript(selectedId, top)
        }
        return
      }
      if (!d.blockId) return
      const id = d.blockId
      const ws = wsScrollRef.current?.getBoundingClientRect()
      const content = wsContentRef.current?.getBoundingClientRect()
      const inside =
        ws && e.clientX >= ws.left && e.clientX <= ws.right && e.clientY >= ws.top && e.clientY <= ws.bottom
      if (!inside || !content) {
        updateSprite(selectedId, (s) => deleteChain(s, id))
      } else if (target) {
        updateSprite(selectedId, (s) => attach(s, id, target))
      } else {
        const x = Math.max(0, Math.round(e.clientX - d.offsetX - content.left))
        const y = Math.max(0, Math.round(e.clientY - d.offsetY - content.top))
        updateSprite(selectedId, (s) => addScript(s, id, x, y))
      }
    }

    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
    window.addEventListener('pointercancel', onUp)
    return () => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
      window.removeEventListener('pointercancel', onUp)
    }
    // findSnap reads only refs, so it's safe to omit
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDragging, selectedId, engine, updateSprite])

  const beginDrag = (e: ReactPointerEvent<HTMLDivElement>, init: Pick<DragState, 'source' | 'blockId' | 'blockType'>) => {
    if (e.button !== 0) return
    const rect = e.currentTarget.getBoundingClientRect()
    setDragState({
      phase: 'pending',
      ...init,
      startX: e.clientX,
      startY: e.clientY,
      offsetX: e.clientX - rect.left,
      offsetY: e.clientY - rect.top,
      x: e.clientX,
      y: e.clientY,
    })
  }

  const onPaletteBlockDown = useCallback((e: ReactPointerEvent<HTMLDivElement>, type: string) => {
    if (dragRef.current) return
    e.preventDefault()
    beginDrag(e, { source: 'palette', blockType: type })
  }, [])

  const workspaceCtx = useMemo<BlockContext>(
    () => ({
      blocks: selected.blocks,
      touchOptions,
      interactive: true,
      onBlockPointerDown: (e, id) => {
        if (isEditable(e.target)) return
        e.stopPropagation()
        if (dragRef.current) return
        e.preventDefault()
        beginDrag(e, { source: 'workspace', blockId: id })
      },
      onInputChange: (id, name, value) =>
        updateSprite(selectedId, (s) => {
          const block = s.blocks[id]
          if (!block) return s
          return { ...s, blocks: { ...s.blocks, [id]: { ...block, inputs: { ...block.inputs, [name]: value } } } }
        }),
    }),
    [selected.blocks, touchOptions, selectedId, updateSprite],
  )

  const overlayCtx = useMemo<BlockContext>(
    () => ({ blocks: selected.blocks, touchOptions, interactive: false }),
    [selected.blocks, touchOptions],
  )

  const addSprite = (costume: string) => {
    const base = COSTUMES.find((c) => c.id === costume)?.name ?? 'スプライト'
    const count = project.sprites.filter((s) => s.name.startsWith(base)).length
    const sprite = createEmptySprite(costume, count ? `${base}${count + 1}` : base, 'blue', randomId('sprite'))
    sprite.x = Math.round(Math.random() * 300 - 150)
    sprite.y = Math.round(Math.random() * 200 - 100)
    setProject((p) => ({ sprites: [...p.sprites, sprite], selectedId: sprite.id }))
  }

  const removeSprite = (id: string) => {
    setProject((p) => {
      const sprites = p.sprites.filter((s) => s.id !== id)
      if (sprites.length === 0) return p
      return { sprites, selectedId: p.selectedId === id ? sprites[0].id : p.selectedId }
    })
  }

  const changeSprite = (id: string, props: Partial<Pick<Sprite, 'name' | 'costume' | 'color'>>) => {
    updateSprite(id, (s) => ({ ...s, ...props }))
    engine.setProps(id, props)
  }

  const exportProject = () => {
    const sprites = project.sprites.map((s) => {
      const live = engine.sprites.get(s.id)
      return live
        ? { ...s, x: live.x, y: live.y, dir: live.dir, size: live.size, visible: live.visible, costume: live.costume, color: live.color }
        : s
    })
    const blob = new Blob([JSON.stringify({ version: 1, sprites }, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'my-game.json'
    a.click()
    URL.revokeObjectURL(url)
  }

  const importProject = async (file: File) => {
    try {
      const data = JSON.parse(await file.text())
      if (!Array.isArray(data?.sprites) || data.sprites.length === 0) throw new Error('invalid')
      const sprites: Sprite[] = data.sprites.map((s: Sprite) => {
        if (typeof s.id !== 'string' || typeof s.blocks !== 'object' || !Array.isArray(s.scripts)) {
          throw new Error('invalid')
        }
        const blocks = Object.fromEntries(Object.entries(s.blocks).filter(([, b]) => DEFS[b.type]))
        return { ...s, blocks, scripts: s.scripts.filter((sc) => blocks[sc.id]) }
      })
      engine.reset(sprites)
      setProject({ sprites, selectedId: sprites[0].id })
    } catch {
      window.alert('ファイルを読み込めませんでした。保存したJSONファイルを選んでください。')
    }
  }

  const resetProject = (kind: 'empty' | 'sample') => {
    if (!window.confirm(kind === 'empty' ? '今のゲームを消して、新しく作りますか?' : '見本のゲームに戻しますか?')) return
    const next =
      kind === 'sample'
        ? createSampleProject()
        : (() => {
            const sprite = createEmptySprite('player', 'プレイヤー', 'blue', randomId('sprite'))
            return { sprites: [sprite], selectedId: sprite.id }
          })()
    engine.reset(next.sprites)
    setProject(next)
  }

  return (
    <div className="flex h-dvh flex-col overflow-hidden bg-background select-none">
      <EditorHeader
        onNew={() => resetProject('empty')}
        onSample={() => resetProject('sample')}
        onSave={exportProject}
        onOpen={importProject}
      />

      <main className="flex min-h-0 flex-1 flex-col md:flex-row">
        <div className="flex h-[58dvh] min-h-0 flex-1 md:order-none md:h-auto order-last">
          <Palette
            ref={paletteRef}
            touchOptions={touchOptions}
            dragging={drag?.phase === 'dragging'}
            onBlockPointerDown={onPaletteBlockDown}
          />
          <Workspace
            scrollRef={wsScrollRef}
            contentRef={wsContentRef}
            sprite={selected}
            ctx={workspaceCtx}
            snap={snap}
          />
        </div>

        <aside className="flex w-full shrink-0 flex-col overflow-y-auto border-b bg-card md:w-[360px] md:border-b-0 md:border-l xl:w-[440px]">
          <Stage
            engine={engine}
            onSpritePick={(id) => setProject((p) => ({ ...p, selectedId: id }))}
            onSpriteMoved={(id, x, y) => updateSprite(id, (s) => ({ ...s, x, y }))}
          />
          <SpritePanel
            sprites={project.sprites}
            selectedId={selectedId}
            onSelect={(id) => setProject((p) => ({ ...p, selectedId: id }))}
            onAdd={addSprite}
            onRemove={removeSprite}
            onChange={changeSprite}
          />
        </aside>
      </main>

      {drag?.phase === 'dragging' && drag.blockId && selected.blocks[drag.blockId] && (
        <div
          className="pointer-events-none fixed z-50 opacity-95 drop-shadow-[0_8px_12px_rgba(15,23,42,0.25)]"
          style={{ left: drag.x - drag.offsetX, top: drag.y - drag.offsetY }}
        >
          <BlockStack startId={drag.blockId} ctx={overlayCtx} />
        </div>
      )}
    </div>
  )
}
