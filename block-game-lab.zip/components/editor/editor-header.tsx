'use client'

import { useRef } from 'react'
import { BookOpen, Download, FilePlus2, FolderOpen, Puzzle } from 'lucide-react'
import { Button } from '@/components/ui/button'

type EditorHeaderProps = {
  onNew: () => void
  onSample: () => void
  onSave: () => void
  onOpen: (file: File) => void
}

export function EditorHeader({ onNew, onSample, onSave, onOpen }: EditorHeaderProps) {
  const fileRef = useRef<HTMLInputElement>(null)

  return (
    <header className="flex h-14 shrink-0 items-center justify-between gap-3 border-b bg-card px-4">
      <div className="flex items-center gap-2.5">
        <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
          <Puzzle className="size-5" aria-hidden />
        </span>
        <div className="leading-tight">
          <h1 className="text-base font-bold">ブロックゲームラボ</h1>
          <p className="hidden text-[11px] text-muted-foreground sm:block">ブロックをつなげてゲームを作ろう</p>
        </div>
      </div>

      <div className="flex items-center gap-1">
        <Button type="button" variant="ghost" size="sm" onClick={onNew}>
          <FilePlus2 className="size-4" aria-hidden />
          <span className="hidden sm:inline">新規</span>
        </Button>
        <Button type="button" variant="ghost" size="sm" onClick={onSample}>
          <BookOpen className="size-4" aria-hidden />
          <span className="hidden sm:inline">見本</span>
        </Button>
        <Button type="button" variant="ghost" size="sm" onClick={() => fileRef.current?.click()}>
          <FolderOpen className="size-4" aria-hidden />
          <span className="hidden sm:inline">開く</span>
        </Button>
        <Button type="button" variant="outline" size="sm" onClick={onSave}>
          <Download className="size-4" aria-hidden />
          <span className="hidden sm:inline">保存</span>
        </Button>
        <input
          ref={fileRef}
          type="file"
          accept="application/json,.json"
          className="sr-only"
          tabIndex={-1}
          aria-hidden
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (file) onOpen(file)
            e.target.value = ''
          }}
        />
      </div>
    </header>
  )
}
