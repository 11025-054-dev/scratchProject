'use client'

import { useEffect, useRef, useState } from 'react'
import { Plus, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import type { Sprite } from '@/lib/blocks'
import { COLORS, COSTUMES, colorHex, drawCostume } from '@/lib/costumes'
import { cn } from '@/lib/utils'

export function SpriteThumb({ costume, color, size = 44 }: { costume: string; color: string; size?: number }) {
  const ref = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    const ctx = ref.current?.getContext('2d')
    if (!ctx) return
    ctx.setTransform(2, 0, 0, 2, 0, 0)
    ctx.clearRect(0, 0, size, size)
    ctx.translate(size / 2, size / 2)
    drawCostume(ctx, costume, colorHex(color), size * 0.36)
  }, [costume, color, size])
  return <canvas ref={ref} width={size * 2} height={size * 2} style={{ width: size, height: size }} aria-hidden />
}

type SpritePanelProps = {
  sprites: Sprite[]
  selectedId: string
  onSelect: (id: string) => void
  onAdd: (costume: string) => void
  onRemove: (id: string) => void
  onChange: (id: string, props: Partial<Pick<Sprite, 'name' | 'costume' | 'color'>>) => void
}

export function SpritePanel({ sprites, selectedId, onSelect, onAdd, onRemove, onChange }: SpritePanelProps) {
  const [adding, setAdding] = useState(false)
  const selected = sprites.find((s) => s.id === selectedId)

  return (
    <section aria-labelledby="sprites-heading" className="flex flex-col gap-3 border-t p-3">
      <div className="flex items-center justify-between">
        <h2 id="sprites-heading" className="text-sm font-bold">
          スプライト
        </h2>
        <Button
          type="button"
          size="sm"
          variant={adding ? 'secondary' : 'outline'}
          onClick={() => setAdding((v) => !v)}
          aria-expanded={adding}
        >
          <Plus className="size-4" aria-hidden />
          追加
        </Button>
      </div>

      {adding && (
        <div className="grid grid-cols-6 gap-1.5 rounded-lg border bg-muted/60 p-2">
          {COSTUMES.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => {
                onAdd(c.id)
                setAdding(false)
              }}
              className="flex flex-col items-center gap-0.5 rounded-md p-1 text-[10px] font-bold hover:bg-card"
            >
              <SpriteThumb costume={c.id} color="blue" size={32} />
              {c.name}
            </button>
          ))}
        </div>
      )}

      <ul className="grid grid-cols-4 gap-2">
        {sprites.map((s) => (
          <li key={s.id} className="relative">
            <button
              type="button"
              onClick={() => onSelect(s.id)}
              aria-pressed={s.id === selectedId}
              className={cn(
                'flex w-full flex-col items-center gap-1 rounded-lg border-2 bg-card p-1.5 text-[11px] font-bold transition-colors',
                s.id === selectedId ? 'border-primary bg-accent' : 'border-transparent hover:border-border',
              )}
            >
              <SpriteThumb costume={s.costume} color={s.color} />
              <span className="w-full truncate text-center">{s.name}</span>
            </button>
            {sprites.length > 1 && s.id === selectedId && (
              <button
                type="button"
                onClick={() => onRemove(s.id)}
                aria-label={`${s.name}を削除`}
                className="absolute -top-1.5 -right-1.5 flex size-5 items-center justify-center rounded-full bg-destructive text-white shadow"
              >
                <X className="size-3" aria-hidden />
              </button>
            )}
          </li>
        ))}
      </ul>

      {selected && (
        <div className="flex flex-col gap-3 rounded-lg border bg-card p-3">
          <label className="flex items-center gap-2 text-xs font-bold">
            <span className="w-16 shrink-0 text-muted-foreground">名前</span>
            <input
              value={selected.name}
              onChange={(e) => onChange(selected.id, { name: e.target.value })}
              className="h-8 min-w-0 flex-1 rounded-md border bg-background px-2 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring/50"
            />
          </label>
          <div className="flex items-center gap-2 text-xs font-bold">
            <span className="w-16 shrink-0 text-muted-foreground">見た目</span>
            <div className="flex flex-wrap gap-1">
              {COSTUMES.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => onChange(selected.id, { costume: c.id })}
                  aria-label={c.name}
                  aria-pressed={selected.costume === c.id}
                  className={cn(
                    'rounded-md border-2 p-0.5',
                    selected.costume === c.id ? 'border-primary' : 'border-transparent hover:border-border',
                  )}
                >
                  <SpriteThumb costume={c.id} color={selected.color} size={26} />
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs font-bold">
            <span className="w-16 shrink-0 text-muted-foreground">色</span>
            <div className="flex flex-wrap gap-1.5">
              {COLORS.map((c) => (
                <button
                  key={c.value}
                  type="button"
                  onClick={() => onChange(selected.id, { color: c.value })}
                  aria-label={c.label}
                  aria-pressed={selected.color === c.value}
                  className={cn(
                    'size-6 rounded-full border-2 border-white ring-2',
                    selected.color === c.value ? 'ring-foreground' : 'ring-transparent hover:ring-border',
                  )}
                  style={{ background: c.hex }}
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </section>
  )
}
