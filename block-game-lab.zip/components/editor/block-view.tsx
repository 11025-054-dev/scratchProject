'use client'

import type { CSSProperties, PointerEvent as ReactPointerEvent } from 'react'
import { CATEGORY_MAP, DEFS, isC, isCap, type Block, type InputSpec, type Option } from '@/lib/blocks'
import { cn } from '@/lib/utils'

export type BlockContext = {
  blocks: Record<string, Block>
  touchOptions: Option[]
  interactive: boolean
  onBlockPointerDown?: (e: ReactPointerEvent<HTMLDivElement>, id: string) => void
  onInputChange?: (id: string, name: string, value: string) => void
}

export function BlockStack({ startId, ctx }: { startId: string | null; ctx: BlockContext }) {
  const ids: string[] = []
  let id = startId
  const seen = new Set<string>()
  while (id && ctx.blocks[id] && !seen.has(id)) {
    seen.add(id)
    ids.push(id)
    id = ctx.blocks[id].next
  }
  return (
    <div className="flex flex-col items-start">
      {ids.map((blockId) => (
        <BlockView key={blockId} block={ctx.blocks[blockId]} ctx={ctx} />
      ))}
    </div>
  )
}

function optionsFor(spec: InputSpec, ctx: BlockContext, value: string): Option[] {
  const list = spec.options === 'touch' ? ctx.touchOptions : (spec.options ?? [])
  if (value && !list.some((o) => o.value === value)) return [...list, { value, label: '(なし)' }]
  return list
}

function InputField({ spec, block, ctx }: { spec: InputSpec; block: Block; ctx: BlockContext }) {
  const value = block.inputs[spec.name] ?? ''

  if (spec.kind === 'select') {
    const options = optionsFor(spec, ctx, value)
    const label = options.find((o) => o.value === value)?.label ?? value
    if (!ctx.interactive) {
      return (
        <span className="rounded-full border border-black/15 bg-black/15 px-2.5 py-0.5 text-white">
          {label} {'▾'}
        </span>
      )
    }
    return (
      <select
        aria-label={spec.name}
        value={value}
        onChange={(e) => ctx.onInputChange?.(block.id, spec.name, e.target.value)}
        className="cursor-pointer rounded-full border border-black/15 bg-black/15 px-2 py-0.5 font-bold text-white outline-none focus-visible:ring-2 focus-visible:ring-white"
      >
        {options.map((o) => (
          <option key={o.value} value={o.value} className="text-foreground">
            {o.label}
          </option>
        ))}
      </select>
    )
  }

  const width = `${Math.max(2, [...value].length * (spec.kind === 'text' ? 1.9 : 1)) + 1.6}ch`
  if (!ctx.interactive) {
    return (
      <span
        className="inline-block rounded-full bg-white px-2 py-0.5 text-center font-bold text-slate-700"
        style={{ minWidth: '2.6rem' }}
      >
        {value}
      </span>
    )
  }
  return (
    <input
      aria-label={spec.name}
      type="text"
      inputMode={spec.kind === 'number' ? 'decimal' : 'text'}
      value={value}
      onChange={(e) => ctx.onInputChange?.(block.id, spec.name, e.target.value)}
      className="rounded-full bg-white px-2 py-0.5 text-center font-bold text-slate-700 outline-none focus-visible:ring-2 focus-visible:ring-slate-900/40"
      style={{ width, minWidth: '2.6rem', maxWidth: '14rem' }}
    />
  )
}

function Row({ block, ctx, className }: { block: Block; ctx: BlockContext; className?: string }) {
  const def = DEFS[block.type]
  return (
    <div
      className={cn(
        'flex min-h-10 items-center gap-1.5 border border-[var(--block-dark)] bg-[var(--block)] px-2.5 py-1.5 text-[13px] font-bold whitespace-nowrap text-white',
        className,
      )}
    >
      {def.parts.map((part, i) =>
        typeof part === 'string' ? (
          <span key={i}>{part}</span>
        ) : (
          <InputField key={i} spec={part} block={block} ctx={ctx} />
        ),
      )}
    </div>
  )
}

function Tab() {
  return (
    <span
      aria-hidden
      className="pointer-events-none absolute top-full left-3 z-10 -mt-px h-1.5 w-6 rounded-b-sm border-x border-b border-[var(--block-dark)] bg-[var(--block)]"
    />
  )
}

export function BlockView({ block, ctx }: { block: Block; ctx: BlockContext }) {
  const def = DEFS[block.type]
  if (!def) return null
  const cat = CATEGORY_MAP[def.category]
  const hat = def.shape === 'hat'
  const cShape = isC(block.type)
  const hasAfter = !isCap(block.type)
  const style = { '--block': cat.color, '--block-dark': cat.dark } as CSSProperties

  return (
    <div
      data-snap-kind={ctx.interactive && hasAfter ? 'after' : undefined}
      data-snap-id={ctx.interactive ? block.id : undefined}
      onPointerDown={ctx.onBlockPointerDown ? (e) => ctx.onBlockPointerDown?.(e, block.id) : undefined}
      className="relative cursor-grab touch-none select-none"
      style={style}
    >
      {cShape ? (
        <div className="flex flex-col">
          <Row block={block} ctx={ctx} className="rounded-t-md rounded-br-md" />
          <div className="flex">
            <div className="w-4 shrink-0 border-x border-[var(--block-dark)] bg-[var(--block)]" />
            <div
              data-snap-kind={ctx.interactive ? 'mouth' : undefined}
              data-snap-id={ctx.interactive ? block.id : undefined}
              className="min-h-7 min-w-20 py-0.5"
            >
              {block.child && <BlockStack startId={block.child} ctx={ctx} />}
            </div>
          </div>
          <div className="flex h-5 w-28 items-center rounded-tr-md rounded-b-md border border-[var(--block-dark)] bg-[var(--block)] px-2.5">
            {def.shape === 'c-cap' && <span className="text-[11px] text-white/80">{'↻'}</span>}
          </div>
        </div>
      ) : (
        <Row block={block} ctx={ctx} className={hat ? 'rounded-md rounded-t-2xl pt-3' : 'rounded-md'} />
      )}
      {hasAfter && <Tab />}
    </div>
  )
}
