'use client'

import { useMemo, useRef, type PointerEvent as ReactPointerEvent, type Ref } from 'react'
import { Trash2 } from 'lucide-react'
import { CATEGORIES, PALETTE, createBlock, type Block, type CategoryId, type Option } from '@/lib/blocks'
import { BlockView, type BlockContext } from './block-view'

type PaletteProps = {
  ref?: Ref<HTMLDivElement>
  touchOptions: Option[]
  dragging: boolean
  onBlockPointerDown: (e: ReactPointerEvent<HTMLDivElement>, type: string) => void
}

const PREVIEW_BLOCKS: Record<string, Block> = Object.fromEntries(
  Object.values(PALETTE)
    .flat()
    .map((type) => [`palette-${type}`, createBlock(type, {}, `palette-${type}`)]),
)

export function Palette({ ref, touchOptions, dragging, onBlockPointerDown }: PaletteProps) {
  const listRef = useRef<HTMLDivElement>(null)

  const ctx = useMemo<BlockContext>(
    () => ({
      blocks: PREVIEW_BLOCKS,
      touchOptions,
      interactive: false,
      onBlockPointerDown: (e, id) => onBlockPointerDown(e, PREVIEW_BLOCKS[id].type),
    }),
    [touchOptions, onBlockPointerDown],
  )

  const scrollTo = (id: CategoryId) => {
    const el = listRef.current?.querySelector<HTMLElement>(`[data-category="${id}"]`)
    if (el && listRef.current) listRef.current.scrollTo({ top: el.offsetTop - 8, behavior: 'smooth' })
  }

  return (
    <div ref={ref} className="relative flex min-h-0 border-r bg-card">
      <nav aria-label="ブロックのカテゴリ" className="flex w-16 shrink-0 flex-col gap-1 overflow-y-auto border-r py-2">
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => scrollTo(c.id)}
            className="flex flex-col items-center gap-1 rounded-md px-1 py-1.5 text-[11px] font-bold text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <span
              aria-hidden
              className="size-5 rounded-full border-2"
              style={{ background: c.color, borderColor: c.dark }}
            />
            {c.name}
          </button>
        ))}
      </nav>

      <div ref={listRef} className="relative w-56 overflow-y-auto overflow-x-hidden px-3 pb-24">
        {CATEGORIES.map((c) => (
          <section key={c.id} data-category={c.id} aria-labelledby={`cat-${c.id}`} className="pt-3">
            <h2 id={`cat-${c.id}`} className="mb-2 text-sm font-bold text-foreground">
              {c.name}
            </h2>
            <div className="flex flex-col items-start gap-3">
              {PALETTE[c.id].map((type) => (
                <BlockView key={type} block={PREVIEW_BLOCKS[`palette-${type}`]} ctx={ctx} />
              ))}
            </div>
          </section>
        ))}
      </div>

      {dragging && (
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-2 bg-background/80 text-muted-foreground backdrop-blur-[1px]">
          <Trash2 className="size-8" aria-hidden />
          <p className="text-sm font-bold">ここに置くと削除</p>
        </div>
      )}
    </div>
  )
}
