'use client'

import type { Ref } from 'react'
import { MousePointerClick } from 'lucide-react'
import type { Sprite } from '@/lib/blocks'
import { BlockStack, type BlockContext } from './block-view'

export type SnapTarget = { kind: 'after' | 'mouth'; id: string; x: number; y: number }

type WorkspaceProps = {
  scrollRef?: Ref<HTMLDivElement>
  contentRef?: Ref<HTMLDivElement>
  sprite: Sprite
  ctx: BlockContext
  snap: SnapTarget | null
}

export function Workspace({ scrollRef, contentRef, sprite, ctx, snap }: WorkspaceProps) {
  return (
    <div className="relative flex min-h-0 min-w-0 flex-1 flex-col">
      <div className="pointer-events-none absolute top-3 left-3 z-10 rounded-full border bg-card/90 px-3 py-1 text-xs font-bold text-muted-foreground shadow-sm">
        {sprite.name} のコード
      </div>
      <div
        ref={scrollRef}
        className="min-h-0 flex-1 overflow-auto"
        style={{
          backgroundImage: 'radial-gradient(circle, oklch(0.86 0.015 265) 1px, transparent 1px)',
          backgroundSize: '22px 22px',
        }}
      >
        <div ref={contentRef} className="relative h-[1400px] w-[1600px]">
          {sprite.scripts.map((script) => (
            <div key={script.id} className="absolute" style={{ left: script.x, top: script.y }}>
              <BlockStack startId={script.id} ctx={ctx} />
            </div>
          ))}

          {snap && (
            <div
              aria-hidden
              className="pointer-events-none absolute z-20 h-1.5 w-32 rounded-full bg-slate-900/40"
              style={{ left: snap.x, top: snap.y - 3 }}
            />
          )}
        </div>
      </div>

      {sprite.scripts.length === 0 && (
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center text-muted-foreground">
          <MousePointerClick className="size-10" aria-hidden />
          <p className="max-w-64 text-sm leading-relaxed font-bold text-balance">
            左のパレットからブロックをドラッグして、ここでつなげよう
          </p>
        </div>
      )}
    </div>
  )
}
